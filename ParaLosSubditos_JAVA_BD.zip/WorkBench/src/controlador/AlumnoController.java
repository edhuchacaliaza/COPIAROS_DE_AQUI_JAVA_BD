/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.Alumno;
import modelo.Conexion;
//1.driver manager
//2.establecer conexion
//3.sentencia sql con un objeto del tipo statement
//4.leer el resultadoo de sql 
/**
 *
 * @author Usuario
 */
public class AlumnoController {
    
    
    public AlumnoController(){
        
    }
    
    //recuperar datos del resultSet 
    public ArrayList<Alumno> mostrarAlumno() {
        
        ArrayList<Alumno> listaAlumno = new ArrayList<Alumno>();

        Conexion conecControl = new Conexion();
        Connection cn = conecControl.conectar();
        
        String sql = "SELECT * FROM tbl_alumno";
        
         try {
            // crear el statement
            Statement st = cn.createStatement();
            // lanzar la consulta
            ResultSet rs = st.executeQuery(sql);
            //lanza consulta con "executequery"
            while(rs.next()){
                //recurrer el resultSet
                Alumno al = new Alumno();
                al.setAlu_id(rs.getInt("alu_id"));
                al.setAlu_nombre(rs.getString("alu_nombre"));
                al.setAlu_apellido1(rs.getString("alu_apellido1"));
                al.setAlu_apellido2(rs.getString("alu_apellido2"));
                al.setAlu_correo(rs.getString("alu_correo"));
                listaAlumno.add(al);
            }
        } catch (SQLException ex) {
            
        }finally{
            try{
            cn.close();
            }catch (SQLException e){
                JOptionPane.showMessageDialog(null, "no se ha cerrado la conexión");
            }
            return listaAlumno; 
        }
    }
}
