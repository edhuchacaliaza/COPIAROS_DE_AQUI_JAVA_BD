/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Alumno {
    //atributos
    private int alu_id;
    private String alu_nombre;
    private String alu_apellido1;
    private String alu_apellido2;
    private String alu_correo;

    public Alumno() {
    }

    public Alumno(int alu_id, String alu_nombre, String alu_apellido1, String alu_apellido2, String alu_correo) {
        this.alu_id = alu_id;
        this.alu_nombre = alu_nombre;
        this.alu_apellido1 = alu_apellido1;
        this.alu_apellido2 = alu_apellido2;
        this.alu_correo = alu_correo;
    }

    public int getAlu_id() {
        return alu_id;
    }

    public String getAlu_nombre() {
        return alu_nombre;
    }

    public String getAlu_apellido1() {
        return alu_apellido1;
    }

    public String getAlu_apellido2() {
        return alu_apellido2;
    }

    public String getAlu_correo() {
        return alu_correo;
    }

    public void setAlu_id(int alu_id) {
        this.alu_id = alu_id;
    }

    public void setAlu_nombre(String alu_nombre) {
        this.alu_nombre = alu_nombre;
    }

    public void setAlu_apellido1(String alu_apellido1) {
        this.alu_apellido1 = alu_apellido1;
    }

    public void setAlu_apellido2(String alu_apellido2) {
        this.alu_apellido2 = alu_apellido2;
    }

    public void setAlu_correo(String alu_correo) {
        this.alu_correo = alu_correo;
    }
    
    
}
